<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-02-10 07:40:29 --> Config Class Initialized
INFO - 2019-02-10 07:40:29 --> Hooks Class Initialized
DEBUG - 2019-02-10 07:40:29 --> UTF-8 Support Enabled
INFO - 2019-02-10 07:40:29 --> Utf8 Class Initialized
INFO - 2019-02-10 07:40:29 --> URI Class Initialized
DEBUG - 2019-02-10 07:40:29 --> No URI present. Default controller set.
INFO - 2019-02-10 07:40:29 --> Router Class Initialized
INFO - 2019-02-10 07:40:29 --> Output Class Initialized
INFO - 2019-02-10 07:40:29 --> Security Class Initialized
DEBUG - 2019-02-10 07:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-02-10 07:40:29 --> Input Class Initialized
INFO - 2019-02-10 07:40:29 --> Language Class Initialized
INFO - 2019-02-10 07:40:29 --> Loader Class Initialized
INFO - 2019-02-10 07:40:29 --> Helper loaded: utility_helper
INFO - 2019-02-10 07:40:29 --> Helper loaded: url_helper
INFO - 2019-02-10 07:40:29 --> Helper loaded: form_helper
INFO - 2019-02-10 07:40:29 --> Database Driver Class Initialized
INFO - 2019-02-10 07:40:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-02-10 07:40:29 --> Pagination Class Initialized
INFO - 2019-02-10 07:40:29 --> Form Validation Class Initialized
DEBUG - 2019-02-10 07:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-02-10 07:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-02-10 07:40:29 --> Controller Class Initialized
INFO - 2019-02-10 07:40:29 --> Model "ProductCat" initialized
INFO - 2019-02-10 07:40:29 --> Model "Productcat_model" initialized
INFO - 2019-02-10 07:40:29 --> Model "Productgallery_model" initialized
INFO - 2019-02-10 07:40:29 --> Model "Product_model" initialized
ERROR - 2019-02-10 07:40:29 --> Query error: No database selected - Invalid query: SELECT *
FROM `productcat`
INFO - 2019-02-10 07:40:29 --> Language file loaded: language/english/db_lang.php
